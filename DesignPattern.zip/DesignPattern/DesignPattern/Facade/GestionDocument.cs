using System;

namespace DesignPattern.Facade
{
  public interface GestionDocument
  {
    string document(int index);
  }
}