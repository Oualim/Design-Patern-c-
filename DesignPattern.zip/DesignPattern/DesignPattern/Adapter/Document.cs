using System;


namespace DesignPattern.Adapter
{
  public interface Document
  {
    string contenu { set; }
    void dessine();
    void imprime();
  }
}