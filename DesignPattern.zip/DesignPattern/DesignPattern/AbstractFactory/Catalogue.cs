﻿using System;
using DesignPattern.AbstractFactory;
using DesignPattern.AbstractFactory.Interface;

namespace DesignPattern.AbstractFactory
{
  public class Catalogue
  {
    

    public void LoadCatalogue(){
      
    }
  }
}
