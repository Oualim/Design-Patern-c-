namespace DesignPattern.Proxy
{
  public interface Animation
  {
    void dessine();
    void clic();
  }
}