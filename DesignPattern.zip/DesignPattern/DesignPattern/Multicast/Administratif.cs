﻿public class Administratif : Employe
{
 public Administratif(string nom)
  : base(nom)
 {
 }
}

