﻿public interface RecepteurGeneral :
 RecepteurAbstrait<MessageGeneral>
{
}

