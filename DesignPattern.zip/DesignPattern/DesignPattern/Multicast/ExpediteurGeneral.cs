﻿public class ExpediteurGeneral : ExpediteurAbstrait
 <MessageGeneral, RecepteurGeneral>
{
}

