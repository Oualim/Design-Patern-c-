﻿public abstract class MessageAbstrait
{
}

