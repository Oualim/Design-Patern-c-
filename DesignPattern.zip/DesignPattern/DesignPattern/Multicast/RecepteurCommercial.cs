﻿public interface RecepteurCommercial :
 RecepteurAbstrait<MessageCommercial>
{
}

