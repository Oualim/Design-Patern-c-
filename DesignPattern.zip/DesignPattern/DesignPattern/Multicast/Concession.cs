﻿using System;

class Concession
{
 static void Main(string[] args)
 {
  DirectionGenerale directionGenerale = new
   DirectionGenerale();
  DirectionCommerciale directionCommerciale = new
   DirectionCommerciale();
  Commercial commercial1 = new Commercial("Paul");
  Commercial commercial2 = new Commercial("Henri");
  Administratif administratif = new Administratif(
   "Jacques");
  directionGenerale.ajouteRecepteurGeneral(commercial1);
  directionGenerale.ajouteRecepteurGeneral(commercial2);
  directionGenerale.ajouteRecepteurGeneral
   (administratif);
  directionGenerale.envoieMessages();
  directionCommerciale.ajouteRecepteurCommercial
   (commercial1);
  directionCommerciale.ajouteRecepteurCommercial
   (commercial2);
  directionCommerciale.envoieMessages();
 }
}

