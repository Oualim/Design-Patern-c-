﻿public class ExpediteurCommercial :
  ExpediteurAbstrait<MessageCommercial,
   RecepteurCommercial>
{
}

