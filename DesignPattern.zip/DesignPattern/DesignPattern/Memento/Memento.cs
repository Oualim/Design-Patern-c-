namespace DesignPattern.Memento
{
  public interface Memento
  {
  }
}