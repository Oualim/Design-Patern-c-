using System;

namespace DesignPattern.Iterator
{
  public class Vehicule : Element
  {

    public Vehicule(string description) : base(description) { }

    public void affiche()
    {
      Console.WriteLine("Description du v�hicule : " +
        description);
    }
  }
}