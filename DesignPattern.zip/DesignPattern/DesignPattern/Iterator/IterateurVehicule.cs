namespace DesignPattern.Iterator
{
  public class IterateurVehicule : Iterateur<Vehicule>
  {
  }
}