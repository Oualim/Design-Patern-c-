namespace DesignPattern.Decorator
{
  public interface ComposantGraphiqueVehicule
  {
    void affiche();
  }
}