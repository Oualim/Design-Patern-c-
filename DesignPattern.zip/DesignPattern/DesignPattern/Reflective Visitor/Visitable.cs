﻿public interface Visitable
{
}

